# Carteira de Investimentos

**Algoritmos e Pensamento Computacional | 2026-2 — Trabalho Final, Checkpoint 2 (CP2)**  
**Grupo 07**

- Arthur Nascimento
- Gabriel Medeiro Freitas
- Giovanna Lopes de Carvalho
- Kerollyn Monteiro Costa

## Sobre o projeto

O **Carteira de Investimentos** é um programa em linguagem C, executado no terminal, que permite cadastrar e consultar ativos financeiros.

O programa calcula o valor atual de cada ativo, o valor total da carteira e a rentabilidade geral dos investimentos.

O tema do projeto é **inclusão financeira**, relacionado à ODS 8.10 da ONU. Neste checkpoint, o objetivo é praticar o uso de `struct`, vetores, funções e arquivos para armazenar os dados cadastrados.

## Funcionalidades

- **Cadastrar ativo:** informa nome, categoria, quantidade, preço de compra e preço atual.
- **Listar ativos:** exibe os ativos cadastrados, seus valores atuais e suas rentabilidades.
- **Valor total da carteira:** soma o valor atual de todos os ativos cadastrados.
- **Rentabilidade geral:** calcula a rentabilidade da carteira considerando o valor investido e o valor atual.
- **Salvar dados:** grava os ativos no arquivo `carteira.txt`.
- **Carregar dados:** recupera os ativos salvos quando o programa é executado novamente.
- **Sair:** salva os dados e encerra o programa.

## Menu do programa

```text
=== Carteira de Investimentos ===
1 - Cadastrar ativo
2 - Listar ativos
3 - Valor total da carteira
4 - Rentabilidade geral
5 - Sair
```

## Estrutura do projeto

```text
meu-projeto-c/
├── src/
│   ├── main.c
│   ├── funcoes.c
│   └── modulo.c
├── include/
│   ├── funcoes.h
│   └── modulo.h
├── data/
│   └── carteira.txt
└── README.md
```

- `main.c`: contém a função `main`, apresenta o menu e chama as funções conforme a opção escolhida.
- `funcoes.c`: contém as funções de cadastro, listagem, leitura e gravação dos ativos.
- `funcoes.h`: contém os protótipos das funções e a definição do limite de ativos.
- `modulo.c`: contém as funções responsáveis pelos cálculos da carteira.
- `modulo.h`: contém a estrutura `Ativo` e os protótipos das funções de cálculo.
- `carteira.txt`: armazena os dados dos ativos cadastrados.
- `README.md`: apresenta as informações e instruções do projeto.

## Estrutura dos dados

Foi utilizada a `struct Ativo` para guardar as informações de cada investimento.

| Campo | Tipo | Descrição |
|---|---|---|
| `nome` | `char` | Nome do ativo |
| `categoria` | `char` | Categoria do investimento |
| `quantidade` | `int` | Quantidade de ativos |
| `precoCompra` | `float` | Preço de compra de cada unidade |